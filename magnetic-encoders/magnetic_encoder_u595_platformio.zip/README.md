# STM32U595QII6Q：PlatformIO 免按键烧录复现

实验日期：2026-11-21。完整结论见[选型报告的烧录部分](https://lijinzh.github.io/magnetic-encoders/#flash)。本包的默认 Upload 目标编译六路 Arduino I²C 草图，将固件传给上传脚本，并在内存中演练写入、读回及复位。板级验收项目列在报告末尾。

## Linux 上复现实验

用 PlatformIO Core 6.2.0、Arduino CLI 1.6.0 和 Python 3。将工作目录切换到解压后的工程目录，执行：

```bash
arduino-cli core update-index --additional-urls https://github.com/stm32duino/BoardManagerFiles/raw/main/package_stmicroelectronics_index.json
arduino-cli core install STMicroelectronics:stm32@3.1.0 --additional-urls https://github.com/stm32duino/BoardManagerFiles/raw/main/package_stmicroelectronics_index.json
export U595_PIO_PACKAGES="$(python3 prepare_packages.py "$HOME/.arduino15")"
pio run -e u595qii -t upload
```

若 Arduino CLI 使用其他 `directories.data`，以 `arduino-cli config dump` 显示的该目录替换 `$HOME/.arduino15`。准备脚本在当前工程生成 PlatformIO 本地包视图，使用 STM32duino 3.1.0、CMSIS 6.3.0、CMSIS DSP 1.17.0 和该 Arduino Core 配套的 xPack GCC 14.2.1-1.1。UFBGA132 引脚来自原厂 variant，链接脚本取自同芯片的 LQFP144 variant。默认运行会打印原始烧录时序与三条模拟结果；`experiment.log` 记录本次实际命令输出。

## 接夹具后的台架操作

1. 按报告接线：外置夹具 DTR# 经反相接 BOOT0，RTS# 经非反相开漏接 NRST，共地并匹配 3.3 V；掌板 USB‑C 接 PC。台架使用一块 STM32 ROM DFU 目标，BOOT 参数用 AN2606 Pattern 12，可读的 RDP Level 0。安装 dfu-util 0.11，配置 DFU 与串口设备权限。
2. 下面的 `PYTHON` 应是安装 PlatformIO 的 Python 解释器，或已安装 pySerial 的 Python。把示例路径换成专用夹具的固定串口名称。用夹具进 ROM 并登记内部 Flash 的 DFU 序号（检查列表中的 `alt=0`、起址和序号）；此命令只枚举接口。

   ```bash
   "$PYTHON" upload.py --identify --port /dev/serial/by-id/替换为夹具
   ```

3. 自制掌板的应用固件按实际晶振配置系统与 USB PHY 时钟，再将 `platformio.ini` 中的默认上传命令替换为：

   ```ini
   upload_command = "$PYTHONEXE" "$PROJECT_DIR/upload.py" --flash --port "/dev/serial/by-id/替换为夹具" --dfu-serial "替换为DFU序号" "$SOURCE"
   ```

   之后执行 `pio run -e u595qii -t upload`，或在 VS Code 点击 Upload。用 VS Code 时，让它继承 `U595_PIO_PACKAGES`，或把 ini 中的 `${sysenv.U595_PIO_PACKAGES}` 换成生成包视图的绝对路径。业务 CDC 用掌板自身的 USB 端口。控制夹具专用于烧录。

脚本从 `0x08000000` 写入非 TrustZone 应用，并以逐字节读回为校验依据。读回通过后发出 NRST 硬件复位脉冲；若写入或校验失败，修正原因后重新运行 Upload。上板验收包含打开/关闭控制串口的瞬态和 CDC 枚举。
