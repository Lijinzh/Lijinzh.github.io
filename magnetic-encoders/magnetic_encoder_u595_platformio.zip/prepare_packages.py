"""把 Arduino CLI 已安装的 ST 3.1.0 包注册为本地 PlatformIO 测试包。"""

import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("arduino_data", type=Path, help="Arduino CLI directories.data")
args = parser.parse_args()
st = args.arduino_data.expanduser().resolve() / "packages" / "STMicroelectronics"
source = st / "hardware" / "stm32" / "3.1.0"
tools = st / "tools"
packages = Path(__file__).resolve().parent / "packages"
gcc = tools / "xpack-arm-none-eabi-gcc" / "14.2.1-1.1"
cmsis = tools / "CMSIS" / "6.3.0" / "CMSIS"
dsp = tools / "CMSIS_DSP" / "1.17.0"
for expected in (source / "platform.txt", gcc / "bin", cmsis / "Core", dsp / "Include"):
    if not expected.exists():
        parser.error(f"请先安装 STM32duino 3.1.0 和配套工具：缺少 {expected}")


def link(src, dst):
    if dst.is_symlink() and dst.resolve() == src.resolve():
        return
    dst.symlink_to(src, target_is_directory=src.is_dir())


def package(name, version, srcs):
    folder = packages / name
    folder.mkdir(parents=True, exist_ok=True)
    for item in srcs:
        link(item, folder / item.name)
    (folder / "package.json").write_text(json.dumps(version) + "\n")


package("core", dict(name="framework-arduinoststm32", version="3.1.0"),
        (source / name for name in ("cores", "libraries", "system", "tools", "variants")))
package("gcc", dict(name="toolchain-gccarmnoneeabi", version="1.140201.0"),
        (item for item in gcc.iterdir() if item.name != "package.json"))
package("cmsis", dict(name="framework-cmsis", version="2.60300.0"), ())
core_view = packages / "cmsis" / "CMSIS"
core_view.mkdir(exist_ok=True)
link(cmsis / "Core", core_view / "Core")
link(dsp, core_view / "DSP")
package("dsp", dict(name="framework-cmsis-dsp", version="1.17.0"),
        (dsp / name for name in ("Include", "PrivateInclude", "Source")))
variants = source / "variants" / "STM32U5xx"
u595 = variants / "U595Q(I-J)IxQ_U5A5Q(I-J)IxQ"
lqfp144 = variants / "U595Z(I-J)TxQ_U599Z(I-J)TxQ_U5A5ZJTxQ_U5A9ZJTxQ"
variant_view = packages / "variants" / "u595qii"
variant_view.mkdir(parents=True, exist_ok=True)
for name in ("PeripheralPins.c", "PinNamesVar.h", "generic_clock.c",
             "variant_generic.cpp", "variant_generic.h"):
    link(u595 / name, variant_view / name)
link(lqfp144 / "ldscript.ld", variant_view / "ldscript.ld")
print(packages)
