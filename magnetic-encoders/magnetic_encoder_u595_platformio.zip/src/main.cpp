#include <Arduino.h>
#include <Wire.h>

// 构造函数参数为 SDA、SCL；ALT1 为 I²C4 和 I²C6 选择对应的引脚复用。
TwoWire bus1(PB7, PB6);
TwoWire bus2(PB14, PB13);
TwoWire bus3(PC1, PC0);
TwoWire bus4(PB11_ALT1, PB10_ALT1);
TwoWire bus5(PD0, PD1);
TwoWire bus6(PF0 | ALT1, PF1 | ALT1);
TwoWire* const buses[] = {&bus1, &bus2, &bus3, &bus4, &bus5, &bus6};
I2C_TypeDef* const expected[] = {I2C1, I2C2, I2C3, I2C4, I2C5, I2C6};

// Arduino 负责组织，HAL 句柄用来核对是否确实绑定到各自的外设。
void setup() {
  Serial.begin(460800);
  for (unsigned i = 0; i < 6; ++i) {
    buses[i]->begin();
    buses[i]->setClock(400000);
    buses[i]->beginTransmission(0x40);
    buses[i]->write(0xFE);
    if (buses[i]->endTransmission(false) == 0) {
      buses[i]->requestFrom(uint8_t(0x40), size_t(2));
      while (buses[i]->available()) buses[i]->read();
    }
    Serial.println(buses[i]->getHandle()->Instance == expected[i] ? i + 1 : 0);
  }
}

void loop() {
  delay(1000);
}
