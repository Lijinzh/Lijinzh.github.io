"""U595/U599 外置夹具 + ROM DFU。默认模式仅在内存中模拟上传。"""

import argparse
import hashlib
import re
import shutil
import struct
import subprocess
import sys
from contextlib import contextmanager
from pathlib import Path
from tempfile import TemporaryDirectory
from time import sleep

FLASH = 0x08000000
FLASH_SIZE = 2 * 1024 * 1024
ENTRY_PULSE = ["BOOT=1", "50 ms", "NRST=0", "50 ms", "NRST=1",
               "100 ms", "BOOT=0"]
APP_PULSE = ["NRST=0", "50 ms", "NRST=1"]


def image_for(path):
    """检查 Flash 起址的应用向量，并按 16 字节补齐末尾。"""
    size = path.stat().st_size
    if not 8 <= size <= FLASH_SIZE:
        raise ValueError("固件大小应为 8 B 至 2 MiB")
    image = path.read_bytes()
    msp, reset = struct.unpack_from("<II", image)
    if not (0x20000000 < msp <= 0x20300000 and msp % 8 == 0
            and reset & 1 and FLASH <= (reset & ~1) < FLASH + len(image)):
        raise ValueError("烧录目标应为链接至 0x08000000 的 U595 应用 .bin")
    return image + b"\xff" * (-len(image) % 16)


def enter_rom(bridge, wait):
    """拉高 BOOT0，释放 NRST 后保持一段时间，再恢复 BOOT0。"""
    bridge.dtr = True
    wait(0.05)
    bridge.rts = True
    wait(0.05)
    bridge.rts = False
    wait(0.10)
    bridge.dtr = False


def program(bridge, wait, transfer, image):
    """夹具串口在进 ROM、写入校验和复位期间保持开启。"""
    enter_rom(bridge, wait)
    readback = transfer(image)
    if readback != image:
        raise ValueError("Flash 读回数据与 .bin 不一致")
    bridge.rts = True
    wait(0.05)
    bridge.rts = False


def simulate(image):
    """以握手线记录和内存 Flash 跑三条路径，并核对复位次序。"""
    for fault in (None, "读回不一致", "写入错误"):
        events = []

        class Fixture:
            @property
            def dtr(self):
                return self.boot

            @dtr.setter
            def dtr(self, value):
                self.boot = value
                events.append(f"BOOT={int(value)}")

            @property
            def rts(self):
                return not self.reset

            @rts.setter
            def rts(self, asserted):
                self.reset = not asserted
                events.append(f"NRST={int(self.reset)}")

        def transfer(payload):
            events.append("DFU 写入")
            if fault == "写入错误":
                raise subprocess.CalledProcessError(1, "dfu-util")
            events.append("DFU 读回")
            if fault == "读回不一致":
                return bytes([payload[0] ^ 1]) + payload[1:]
            return bytes(bytearray(payload))

        try:
            program(Fixture(), lambda sec: events.append(f"{sec * 1000:.0f} ms"),
                    transfer, image)
        except (ValueError, subprocess.CalledProcessError) as exc:
            if fault is None or (fault == "读回不一致") != isinstance(exc, ValueError):
                raise
        else:
            if fault is not None:
                raise RuntimeError("故障注入应返回失败")
        expected = ENTRY_PULSE + ["DFU 写入"]
        if fault != "写入错误":
            expected += ["DFU 读回"]
        if fault is None:
            expected += APP_PULSE
        if events != expected:
            raise RuntimeError(f"意外的夹具时序：{events}")
        print(f"[模拟] {fault or '写入、校验和复位'}：{' → '.join(events)}")


@contextmanager
def fixture(port):
    """夹具串口仅打开一次，握手线空闲时保持释放。"""
    import serial  # 使用 PlatformIO Python 环境自带的 pySerial

    with serial.Serial(port=None, rtscts=False, dsrdtr=False) as bridge:
        bridge.port = port
        bridge.dtr = False
        bridge.rts = False
        bridge.open()
        try:
            yield bridge
        finally:
            bridge.dtr = False
            bridge.rts = False


def dfu_tool():
    tool = shutil.which("dfu-util")
    if not tool:
        raise ValueError("请安装 dfu-util，并把它加入 PATH")
    return tool


def identify(port):
    """连接单块掌板，用夹具进入 ROM 后只列出 DFU 接口。"""
    tool = dfu_tool()
    with fixture(port) as bridge:
        enter_rom(bridge, sleep)
        sleep(1)
        subprocess.run([tool, "-l", "-d", ",0483:df11"], check=True, timeout=10)


def flash(port, target, image):
    """仅连接调用者明确指定的夹具串口和 DFU 序号。"""
    if not re.fullmatch(r"[0-9a-fA-F]{12,32}", target):
        raise ValueError("请使用 dfu-util -l 显示的完整 DFU 十六进制序号")
    base = [dfu_tool(), "-d", ",0483:df11", "-S", "," + target, "-a", "0", "-w"]

    def transfer(payload):
        with TemporaryDirectory() as directory:
            binary = Path(directory) / "app.bin"
            readback = Path(directory) / "readback.bin"
            binary.write_bytes(payload)
            subprocess.run([*base, "-s", f"0x{FLASH:08x}", "-D", str(binary)],
                           check=True, timeout=120)
            subprocess.run([*base, "-s", f"0x{FLASH:08x}:{len(payload)}",
                            "-U", str(readback)], check=True, timeout=120)
            return readback.read_bytes()

    with fixture(port) as bridge:
        program(bridge, sleep, transfer, image)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--flash", action="store_true", help="启用真实夹具")
    mode.add_argument("--identify", action="store_true", help="用夹具进入 ROM 并列出 DFU 接口")
    parser.add_argument("--port", help="专用夹具串口")
    parser.add_argument("--dfu-serial", help="预先登记的目标 STM32 ROM DFU 序号")
    parser.add_argument("binary", type=Path, nargs="?")
    args = parser.parse_args()
    try:
        if args.identify:
            if not args.port:
                parser.error("--identify 需要 --port")
            identify(args.port)
            return
        if args.binary is None:
            parser.error("模拟和烧录需要提供 .bin")
        image = image_for(args.binary)
        if args.flash:
            if not (args.port and args.dfu_serial):
                parser.error("--flash 需要 --port 和 --dfu-serial")
            flash(args.port, args.dfu_serial, image)
            print("写入与读回校验通过，已发出应用复位脉冲。")
        else:
            simulate(image)
        print(f"校验负载 {len(image)} B · SHA-256 {hashlib.sha256(image).hexdigest()}")
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        sys.exit(f"上传失败：{exc}")


if __name__ == "__main__":
    main()
